#if defined(__EDG__)
#include_next <bits/c++config.h>
#if defined(_GLIBCXX_USE_FLOAT128)
#undef _GLIBCXX_USE_FLOAT128
#endif
#endif
