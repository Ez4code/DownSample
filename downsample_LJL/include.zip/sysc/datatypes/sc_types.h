
#ifndef SC_TYPES_H
#define SC_TYPES_H

#define SC_DATA_TYPES_ONLY
#include "systemc.h"

#endif
